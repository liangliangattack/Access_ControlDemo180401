/**   
 * Copyright © 2014 All rights reserved.
 * 
 * @Title: Constant.java 
 * @Prject: MQTTClient
 * @Package: com.example.mqttclient 
 * @Description: TODO
 * @author: raot  719055805@qq.com
 * @date: 2014年9月15日 上午11:33:33 
 * @version: V1.0   
 */
package com.lollipop.access_controldemo;

/** 
 * @ClassName: Constant 
 * @Description: TODO
 * @author: raot  719055805@qq.com
 * @date: 2014年9月15日 上午11:33:33  
 */
public class Constant {

	//public static String MQTT_SERVERURL = "tcp://10.151.31.165";
	public static String MQTT_SERVERURL = "tcp://10.113.3.58";
	
	/***************************用户二安装的时候注释掉************************************/
	public static String CLIENT_ID = "用户一";
	public static String CLIENT_TOPIC = "HelloWorld";
	
//	public static String SERVER_ID = "用户二";
//	public static String SERVER_TOPIC = "HelloWorld";
	
	/***************************用户一安装的时候注释掉***********************************/
//	public static String CLIENT_ID = "用户二";
//	public static String CLIENT_TOPIC = "接受用户一信息";
//	
//	public static String SERVER_ID = "用户一";
//	public static String SERVER_TOPIC = "接受用户二信息";
	
}
